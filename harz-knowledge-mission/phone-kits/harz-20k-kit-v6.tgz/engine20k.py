import json, sqlite3, sys, time
print('G1 PASS: sqlite binding = python3-sqlite3')
db = sqlite3.connect('kb20k.sqlite')
intg = db.execute('PRAGMA integrity_check;').fetchone()[0]
print('G2 PASS: integrity ok' if intg == 'ok' else 'G2 FAIL: ' + str(intg))
n = db.execute('SELECT COUNT(*) FROM fts;').fetchone()[0]
print('G3 PASS: rows = 20000 (FTS-only sample, rowid = doc_id)' if n == 20000 else 'G3 FAIL: rows = %d' % n)
try:
    fr = db.execute("SELECT COUNT(*) FROM fts WHERE fts MATCH 'elections';").fetchone()[0]
    print('G4 PASS: FTS5 MATCH returns %d rows' % fr)
except Exception as e:
    print('G4 FAIL: FTS5 error: ' + str(e)); sys.exit(1)
cases = json.load(open('battery-20k.json'))['cases']
top1 = top3 = 0; times = []
t1 = time.time()
for c in cases:
    t0 = time.time()
    try:
        ids = [r[0] for r in db.execute(
            'SELECT rowid FROM fts WHERE fts MATCH ? ORDER BY bm25(fts) LIMIT 3', (c['query'],)).fetchall()]
    except Exception:
        ids = []
    times.append((time.time() - t0) * 1000)
    if ids and ids[0] == c['doc_id']: top1 += 1
    if c['doc_id'] in ids[:3]: top3 += 1
wall = (time.time() - t1) * 1000
avg = sum(times) / len(times)
g5, g6, g7 = avg <= 50, top1 >= 19, top3 >= 19
print('G5 %s: avg query %.1fms (gate <=50ms) | first %.1fms | battery wall %.0fms' % ('PASS' if g5 else 'FAIL', avg, times[0], wall))
print('G6 %s: top1 %d/20 (gate >=19/20)' % ('PASS' if g6 else 'FAIL', top1))
print('G7 %s: top3 %d/20 (gate >=19/20)' % ('PASS' if g7 else 'FAIL', top3))
import resource
print('info: python RSS %dMB' % (resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024))
verdict = 'ALL GATES PASS' if (intg == 'ok' and n == 20000 and g5 and g6 and g7) else 'GATE FAILURE — report output as-is'
print('')
print('== REPORT (paste everything from == HARZ == down) ==')
print('VERDICT:', verdict)
