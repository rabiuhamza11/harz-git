#!/data/data/com.termux/files/usr/bin/bash
# HARZ D1 20K-GATE PHONE TEST v1 — self-contained, read-only, measurement-only.
# Nothing uploads, nothing is modified outside this folder.
# Paste the full output (from "== HARZ" down) back to Nuruddeen.
set -u
cd "$(dirname "$0")"
echo "== HARZ D1 20K GATES — PHONE TEST v1 =="
echo "started: $(date)"
ENGINE="${HARZ_ENGINE:-}"
if [ -z "$ENGINE" ] && command -v node >/dev/null 2>&1; then ENGINE=node; fi
if [ -z "$ENGINE" ] && command -v python3 >/dev/null 2>&1; then ENGINE=python3; fi
if [ -z "$ENGINE" ] && command -v python >/dev/null 2>&1; then ENGINE=python; fi
if [ -z "$ENGINE" ]; then echo "G0 FAIL: need node or python in Termux (pkg install nodejs -y)."; exit 1; fi
echo "G0 PASS: engine = $ENGINE"
[ -f kb20k.sqlite ] || gunzip -kf kb20k.sqlite.gz || { echo "G2 FAIL: decompress"; exit 1; }
if [ "$ENGINE" = "node" ]; then
  node engine20k.mjs || exit 1
else
  "$ENGINE" engine20k.py || exit 1
fi
