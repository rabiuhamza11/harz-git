// HARZ 20K gates — node runner. Prefers node:sqlite, falls back to better-sqlite3.
import { readFileSync } from 'fs';
let Database, via;
try { Database = (await import('node:sqlite')).DatabaseSync; via = 'node:sqlite'; }
catch { try { Database = (await import('better-sqlite3')).default; via = 'better-sqlite3'; }
        catch { console.log('G0 FAIL: node present but no sqlite binding (need node >=22.5 or better-sqlite3). Try: pkg install python -y and rerun (it will auto-switch).'); process.exit(1); } }
console.log('G1 PASS: sqlite binding =', via);
const t00 = Date.now();
const db = via === 'node:sqlite' ? new Database('kb20k.sqlite') : new Database('kb20k.sqlite', { readonly: true });
const intg = db.prepare('PRAGMA integrity_check;').get();
const intgOk = (Object.values(intg)[0] === 'ok');
console.log(intgOk ? 'G2 PASS: integrity ok' : 'G2 FAIL: ' + JSON.stringify(intg));
const n = db.prepare('SELECT COUNT(*) c FROM fts').get().c;
console.log(n === 20000 ? 'G3 PASS: rows = 20000 (FTS-only sample, rowid = doc_id)' : 'G3 FAIL: rows = ' + n);
let ftsRows;
try { ftsRows = db.prepare("SELECT COUNT(*) c FROM fts WHERE fts MATCH 'elections';").get().c;
      console.log('G4 PASS: FTS5 MATCH returns ' + ftsRows + ' rows'); }
catch (e) { console.log('G4 FAIL: FTS5 error: ' + e.message); process.exit(1); }
const cases = JSON.parse(readFileSync('battery-20k.json', 'utf8')).cases;
const q = db.prepare('SELECT rowid FROM fts WHERE fts MATCH ? ORDER BY bm25(fts) LIMIT 3');
let top1 = 0, top3 = 0; const times = [];
const t1 = Date.now();
for (const c of cases) {
  const t0 = Date.now();
  let ids = [];
  try { ids = q.all(c.query).map(r => r.rowid); } catch (e) { ids = []; }
  times.push(Date.now() - t0);
  if (ids[0] === c.doc_id) top1++;
  if (ids.slice(0, 3).includes(c.doc_id)) top3++;
}
const wall = Date.now() - t1;
const avg = times.reduce((a, b) => a + b, 0) / times.length;
const g5 = avg <= 50, g6 = top1 >= 19, g7 = top3 >= 19;
console.log(`G5 ${g5 ? 'PASS' : 'FAIL'}: avg query ${avg.toFixed(1)}ms (gate <=50ms) | first ${times[0]}ms | battery wall ${wall}ms`);
console.log(`G6 ${g6 ? 'PASS' : 'FAIL'}: top1 ${top1}/20 (gate >=19/20)`);
console.log(`G7 ${g7 ? 'PASS' : 'FAIL'}: top3 ${top3}/20 (gate >=19/20)`);
const mem = Math.round(process.memoryUsage().rss / 1048576);
console.log(`info: node RSS ${mem}MB`);
const verdict = (intgOk && n === 20000 && g5 && g6 && g7) ? 'ALL GATES PASS' : 'GATE FAILURE — report output as-is';
console.log('');
console.log('== REPORT (paste everything from "== HARZ" down) ==');
console.log('VERDICT:', verdict);
