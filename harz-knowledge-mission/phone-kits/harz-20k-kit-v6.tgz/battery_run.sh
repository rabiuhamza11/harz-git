#!/data/data/com.termux/files/usr/bin/bash
# shell fallback: per-case timing via sqlite3 CLI
T1=0; TOP1=0; TOP3=0; N=0
i=0
while read -r q; do
  [ -z "$q" ] && continue
  S=$(date +%s%N)
  R=$(sqlite3 kb20k.sqlite "SELECT d.id FROM fts JOIN docs d ON d.id=fts.rowid WHERE fts MATCH '""$q""' ORDER BY bm25(fts) LIMIT 3;" 2>/dev/null | tr '\n' ' ')
  E=$(date +%s%N)
  MS=$(( (E - S) / 1000000 ))
  T1=$((T1 + MS)); N=$((N + 1))
  echo "case $i ms=$MS ids=[$R]"
  i=$((i+1))
done < battery-queries.txt
echo "G5: total ${T1}ms over ${N} cases — divide for avg (gate avg<=50ms)"
