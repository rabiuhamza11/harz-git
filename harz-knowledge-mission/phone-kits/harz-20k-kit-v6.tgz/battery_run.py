import json, sqlite3, time, sys
db = sqlite3.connect("kb20k.sqlite")
cases = json.load(open("battery-20k.json"))["cases"]
t0 = time.time(); top1 = 0; top3 = 0; times = []
for c in cases:
    q = c["query"]
    t = time.time()
    try:
        rows = db.execute(
            "SELECT d.id FROM fts JOIN docs d ON d.id = fts.rowid WHERE fts MATCH ? "
            "ORDER BY bm25(fts) LIMIT 3", (q,)).fetchall()
    except Exception as e:
        rows = []
    times.append((time.time() - t) * 1000)
    ids = [r[0] for r in rows]
    if ids and ids[0] == c["doc_id"]: top1 += 1
    if c["doc_id"] in ids[:3]: top3 += 1
avg = sum(times) / len(times); wall = (time.time() - t0) * 1000
g5 = "PASS" if avg <= 50 else "FAIL"
g6 = "PASS" if top1 >= 19 else "FAIL"
g7 = "PASS" if top3 >= 19 else "FAIL"
print("G5 %s: battery avg query %.1fms (gate <=50ms) | first %.1fms | wall %.0fms" % (g5, avg, times[0], wall))
print("G6 %s: top1 accuracy %d/20 (gate >=19/20)" % (g6, top1))
print("G7 %s: top3 accuracy %d/20 (gate >=19/20)" % (g7, top3))
verdict = "ALL GATES PASS" if (g5 == g6 == g7 == "PASS") else "GATE FAILURE — report as-is, do not retry silently"
print()
print("== REPORT (paste everything from '== HARZ' down) ==")
print("VERDICT:", verdict)
